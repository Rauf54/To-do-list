//
//  ListAllToDoVC.swift
//  To-do
//
//  Created by Abdur Rauf on 29/09/2020.
//  Copyright © 2020 Abdur Rauf. All rights reserved.
//

import UIKit
import CoreData

class ListAllToDoVC: UIViewController {
    
    
    
    @IBOutlet weak var tableView: UITableView!
    var listToShow : [Int] = []
    var listToShowSecond : [Int] = []
    private var places: [NSManagedObject] = []
    var tags = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        inialization()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        retriveFromCoreData()
    }
    
    //MARK:- AddNotes Button Action
    @IBAction func AddNotesAction(_ sender: Any) {
        let vc = AddNotesVC.instantiate(fromAppStoryboard:.Main)
        vc.incoming = "AddNotes"
        show(vc, sender: self)
        
    }
}
//MARK:- Initialization
extension ListAllToDoVC {
    func inialization(){
        retriveFromCoreData()
    }
    func retriveFromCoreData(){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Places")
        
        do {
            places = try managedContext.fetch(fetchRequest)
            tableView.reloadData()
            
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        tableView.reloadData()
        
    }
    //MARK:- Update Data in CoreData
    
    func Update(check : String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let batchUpdate = NSFetchRequest<NSFetchRequestResult>(entityName: "Places")
        
        do {
            let results = try managedContext.fetch(batchUpdate) as? [NSManagedObject]
            if results?.count != 0 { // Atleast one was returned
                
                // In my case, I only updated the first item in results
                results?[0].setValue(check, forKey: "check")
            }
        }
        catch {
            print("Fetch Failed: \(error)")
        }
        
        do {
            try managedContext.save()
        }
        catch {
            print("Saving Core Data Failed: \(error)")
        }
        
    }
    //MARK:- Objc button For checked mark
    @objc func checkOrUncheck(_ sender: UIButton){
        // use the tag of button as index
        let youtuber = sender.convert(CGPoint.zero, to: self.tableView)
        let indexPath = self.tableView.indexPathForRow(at:youtuber)
        let cell = self.tableView.cellForRow(at: indexPath!) as? AllListCell
        tags = sender.tag
        if cell?.checkOrUncek.currentImage != nil{
            listToShowSecond.append(indexPath?.row ?? 0)
            UserDefaults.standard.removeObject(forKey: "row")
            UserDefaults.standard.set(listToShow, forKey: "index")
            cell?.checkOrUncek.setImage(nil, for: .normal)
            
        }else{
            
            cell?.checkOrUncek.setImage(UIImage(named: "Checked"), for: .normal)
            listToShow.append(indexPath?.row ?? 0)
            UserDefaults.standard.set(listToShow, forKey: "row")
            
            
        }
    }
    
}
//====================================================================================
//MARK:- TableView DataSource
//==============================================================================
extension ListAllToDoVC : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return places.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let person = places[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "AllListCell", for: indexPath) as? AllListCell
        cell?.nameLbl.text = person.value(forKeyPath: "name") as? String
        cell?.checkOrUncek.tag = indexPath.row
        let row = UserDefaults.standard.array(forKey: "row")
        for i in 0..<(row?.count ?? 0){
            if row?[i] as? Int == indexPath.row{
                cell?.checkOrUncek.setImage(UIImage(named: "Checked"), for: .normal)
            }else{
                cell?.checkOrUncek.setImage(nil, for: .normal)
            }
        }
        
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        let result = formatter.string(from: date)
        cell?.dateLbl.text = result
        cell?.checkOrUncek.addTarget(self, action: #selector(checkOrUncheck(_:)), for: .touchUpInside)
        
        return cell ?? UITableViewCell()
    }
    
}
//===================================================================================
//MARK:- TableView Delegates
//==============================================================================
extension ListAllToDoVC : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = self.tableView.cellForRow(at: indexPath) as? AllListCell
        let vc = AddNotesVC.instantiate(fromAppStoryboard: .Main)
        vc.titles = cell?.nameLbl.text ?? ""
        vc.incoming = "ListAllToDoVC"
        vc.row = indexPath.row
        show(vc, sender: self)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle:   UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Places")
            
            do {
                let places = try managedContext.fetch(fetchRequest)
                if places.count > 0 {
                    managedContext.delete(places[indexPath.row])
                    tableView.beginUpdates()
                }
                
                do {
                    try managedContext.save()
                    retriveFromCoreData()
                } catch let error as NSError {
                    print(error)
                }
                
            } catch let error as NSError {
                print("Could not fetch. \(error), \(error.userInfo)")
            }
            
            tableView.deleteRows(at: [indexPath], with: .middle)
            tableView.endUpdates()
        }
    }
}
