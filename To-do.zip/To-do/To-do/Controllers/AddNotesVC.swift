//
//  AddNotesVC.swift
//  To-do
//
//  Created by Abdur Rauf on 29/09/2020.
//  Copyright © 2020 Abdur Rauf. All rights reserved.
//

import UIKit
import CoreData


class AddNotesVC: UIViewController {
    
    @IBOutlet weak var textViewList: UITextView!
    private var places: [NSManagedObject] = []
    var titles = ""
    var incoming = ""
    var row = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        initialization()
    }
//MARK:- Done Action
    @IBAction func doneAction(_ sender: Any) {
        if incoming == "ListAllToDoVC"{
            Update(name: textViewList.text)
            navigationController?.popViewController(animated: true)
        }else if incoming == "AddNotes"{
            save(name: textViewList.text)
            navigationController?.popViewController(animated: true)
        }
               
           }
//MARK:- Save in coreData
    
    func save(name : String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Places", in: managedContext)!
        let place = NSManagedObject(entity: entity, insertInto: managedContext)
        place.setValue(name, forKeyPath: "name")
        
        do {
            try managedContext.save()
            places.append(place)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
        
    }
    func Update(name : String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let batchUpdate = NSFetchRequest<NSFetchRequestResult>(entityName: "Places")
        
        do {
            let results = try managedContext.fetch(batchUpdate) as? [NSManagedObject]
            if results?.count != 0 { // Atleast one was returned

                let managedObject = results?[row]
                managedObject?.setValue(name, forKey: "name")
                try managedContext.save()
            }
        }
            catch {
                print("Fetch Failed: \(error)")
            }

            
        
    }
}
//MARK:- Initialization
extension AddNotesVC{
    func initialization(){
        UpdateUi()
        
        
    }
    func UpdateUi(){
        if incoming == "ListAllToDoVC"
        {
            textViewList.text = titles
        }
    }
}
