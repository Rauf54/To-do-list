//
//  StoreData.swift
//  To-do
//
//  Created by Abdur Rauf on 29/09/2020.
//  Copyright © 2020 Abdur Rauf. All rights reserved.
//

import Foundation
struct ListAllElements {
    var name = ""
    var checked = false
        init(name : String){
        self.name = name
        
    }
        
    
}
