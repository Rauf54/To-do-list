//
//  AllListCell.swift
//  To-do
//
//  Created by Abdur Rauf on 29/09/2020.
//  Copyright © 2020 Abdur Rauf. All rights reserved.
//

import UIKit

class AllListCell: UITableViewCell {
    
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var checkOrUncek: UIButton!
    @IBOutlet weak var nameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func uncheckAction(_ sender: Any) {
        
}
}
